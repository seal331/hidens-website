Starcraft 2: Wings of Liberty - Cursor set made by Darc1n

WEBSITE: http://starcraft2.hu

Install:
------------------------------
1. Click "Start" and then click on "Control Panel." If you are using an older version of Windows you will click "Start," point to "Settings" and then click on "Control Panel."

2. If your "Control Panel" is in "Category View", click the option in the task pane that says "Switch to Classic View."

3. In the "Control Panel" double click "Mouse." The "Mouse Properties" dialog box will appear.

4. Click on the "Pointers" tab.

5. Under "Scheme" you can choose a new scheme that will change all of your pointers at once.

6. Under "Customize", you can choose to change the way one pointer appears. To do this, click "Browse", then browse the files of this folder that you wish to use for that particular task.

7. Click "Apply" and "OK".


Telep�t�s:
------------------------------
1. Kattints a "Start" men�re majd a "Vez�rlopult"-ra.

2. Ha a "Vez�rlopult" "Kategoriz�lt n�zet"-ben van, kattint a bal oldals�von a "V�lt�s a klasszikus n�zetre", majd a megjeleno parancsikonokb�l az "Eg�r"-re. (Win7 alatt a Vez�rlopult keresoj�be be�rva az "eg�r" sz�t is meg lehet tal�lni)

3. Megjelenik az "Eg�r be�ll�t�sai" ablak.

4. Kattints a "Mutat�k" f�lre.

5. Az eg�rmutat� ikonokra duplakattal, vagy kiv�laszt�s ut�n a "Tall�z�s" men�bol keresd ki ebbol a k�nyvt�rb�l azt a Starcraft 2-es mutat�t, amivel le szeretn�d cser�lni a jelenlegi kurzort.

6. Katt az "Alkalmaz�s" gombra �s k�sz is. Kisebb ikonokhoz a "24px" nevu mapp�b�l tall�zd ki oket, tov�bb�, mint l�tod l�tezik sima, Protoss �s Zerges kurzor is, kedvedre v�logass k�zt�k.

WEBOLDAL: http://starcraft2.hu